package main

type User struct {
	Id       int
	Name     string
	Email    string
	Password string
}

type UserData []User
