package main

import "time"

type Post struct {
	Id       int
	Caption  string
	ImageUrl string
	Posted   time.Time
}

type PostData []Post
