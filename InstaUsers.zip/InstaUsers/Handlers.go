package main

import (
	"encoding/json"
	"fmt"
	"net/http"
)

func Index(w http.ResponseWriter, r *http.Request) {
	fmt.Fprintln(w, "Welcome!")
}

func Users(w http.ResponseWriter, r *http.Request) {
	users := UserData{
		User{Id: 1, Name: "Arun", Email: "Arun@gmail.com", Password: "pass@123"},
		User{Id: 2, Name: "Bhanu", Email: "Bhanu@gmail.com", Password: "Password"},
	}

	// w.Header().Set("Content-Type", "application/json; charset=UTF-8")
	// w.WriteHeader(http.StatusOK)
	// if err := json.NewEncoder(w).Encode(users); err != nil {
	// 	panic(err)
	// }
	if err := json.NewEncoder(w).Encode(users); err != nil {
		panic(err)
	}

}

func GetUser(w http.ResponseWriter, r *http.Request) {

}

func Posts(w http.ResponseWriter, r *http.Request) {

}

func GetPosts(w http.ResponseWriter, r *http.Request) {

}
